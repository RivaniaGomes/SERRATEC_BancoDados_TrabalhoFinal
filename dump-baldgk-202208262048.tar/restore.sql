--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE baldgk;
--
-- Name: baldgk; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE baldgk WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Portuguese_Brazil.1252';


\connect baldgk

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cliente; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cliente (
    cli_cd_id integer NOT NULL,
    cli_tx_nome_completo character varying(40) NOT NULL,
    cli_tx_nome_de_usuario character varying(20) NOT NULL,
    cli_tx_email character varying(40) NOT NULL,
    cli_tx_cpf character varying(14) NOT NULL,
    cli_dt_data_de_nascimento date,
    cli_tx_cep character varying(10) NOT NULL,
    cli_tx_rua character varying(40) NOT NULL,
    cli_int_numero integer NOT NULL,
    cli_tx_telefone character varying(15)
);


--
-- Name: all_cliente; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.all_cliente AS
 SELECT cliente.cli_cd_id,
    cliente.cli_tx_nome_completo,
    cliente.cli_tx_nome_de_usuario,
    cliente.cli_tx_email,
    cliente.cli_tx_cpf,
    cliente.cli_dt_data_de_nascimento,
    cliente.cli_tx_cep,
    cliente.cli_tx_rua,
    cliente.cli_int_numero,
    cliente.cli_tx_telefone
   FROM public.cliente;


--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.funcionario (
    fun_cd_id integer NOT NULL,
    fun_tx_nome character varying(20) NOT NULL,
    fun_tx_cpf character varying(14) NOT NULL,
    fun_tx_cep character varying(10) NOT NULL,
    fun_tx_rua character varying(40) NOT NULL,
    fun_int_numero integer NOT NULL,
    fun_tx_telefone integer NOT NULL,
    fun_tx_email character varying(40) NOT NULL
);


--
-- Name: all_funcionario; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.all_funcionario AS
 SELECT funcionario.fun_cd_id,
    funcionario.fun_tx_nome,
    funcionario.fun_tx_cpf,
    funcionario.fun_tx_cep,
    funcionario.fun_tx_rua,
    funcionario.fun_int_numero,
    funcionario.fun_tx_telefone,
    funcionario.fun_tx_email
   FROM public.funcionario;


--
-- Name: produto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.produto (
    prd_cd_id integer NOT NULL,
    prd_tx_nome character varying(80) NOT NULL,
    prd_tx_descricao character varying(280),
    prd_int_quantidade_estoque integer NOT NULL,
    prd_dt_data_de_fabricacao date NOT NULL,
    prd_dec_valor_unitario numeric NOT NULL,
    fun_cd_id integer NOT NULL,
    cat_cd_id integer NOT NULL
);


--
-- Name: all_produto; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.all_produto AS
 SELECT produto.prd_cd_id,
    produto.prd_tx_nome,
    produto.prd_tx_descricao,
    produto.prd_int_quantidade_estoque,
    produto.prd_dt_data_de_fabricacao,
    produto.prd_dec_valor_unitario,
    produto.fun_cd_id,
    produto.cat_cd_id
   FROM public.produto;


--
-- Name: categoria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categoria (
    cat_cd_id integer NOT NULL,
    cat_tx_nome character varying(40) NOT NULL,
    cat_tx_descricao character varying(280)
);


--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categoria_cat_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categoria_cat_cd_id_seq OWNED BY public.categoria.cat_cd_id;


--
-- Name: cliente_cli_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cliente_cli_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cliente_cli_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cliente_cli_cd_id_seq OWNED BY public.cliente.cli_cd_id;


--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.funcionario_fun_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.funcionario_fun_cd_id_seq OWNED BY public.funcionario.fun_cd_id;


--
-- Name: nota_fiscal; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nota_fiscal (
    nfe_cd_id integer NOT NULL,
    ped_cd_id integer NOT NULL
);


--
-- Name: nota_fiscal_nfe_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nota_fiscal_nfe_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nota_fiscal_nfe_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nota_fiscal_nfe_cd_id_seq OWNED BY public.nota_fiscal.nfe_cd_id;


--
-- Name: pedido; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pedido (
    ped_cd_id integer NOT NULL,
    ped_dt_data_pedido date NOT NULL,
    cli_cd_id integer NOT NULL
);


--
-- Name: pedido_item; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pedido_item (
    pdt_cd_id integer NOT NULL,
    pdt_int_quantidade integer NOT NULL,
    ped_cd_id integer NOT NULL,
    prd_cd_id integer NOT NULL
);


--
-- Name: pedido_item_pdt_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pedido_item_pdt_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pedido_item_pdt_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pedido_item_pdt_cd_id_seq OWNED BY public.pedido_item.pdt_cd_id;


--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pedido_ped_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pedido_ped_cd_id_seq OWNED BY public.pedido.ped_cd_id;


--
-- Name: produto_prd_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.produto_prd_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: produto_prd_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.produto_prd_cd_id_seq OWNED BY public.produto.prd_cd_id;


--
-- Name: rel_cliente; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.rel_cliente AS
 SELECT cliente.cli_cd_id AS cod_cliente,
    cliente.cli_tx_cpf AS cpf,
    cliente.cli_tx_nome_completo AS nome_completo,
    cliente.cli_tx_nome_de_usuario AS usuario,
    cliente.cli_tx_email AS email,
    (((((cliente.cli_tx_rua)::text || ', '::text) || cliente.cli_int_numero) || ', '::text) || (cliente.cli_tx_cep)::text) AS endereco
   FROM public.cliente;


--
-- Name: rel_pedido_venda; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.rel_pedido_venda AS
 SELECT cliente.cli_tx_nome_de_usuario AS usuario,
    pedido_item.ped_cd_id AS nr_pedido,
    pedido.ped_dt_data_pedido AS data_pedido,
    pedido_item.pdt_int_quantidade AS quantidade,
    categoria.cat_tx_nome AS categoria,
    produto.prd_tx_nome AS nome_produto,
    produto.prd_dec_valor_unitario AS valor_produto,
    (produto.prd_dec_valor_unitario * (pedido_item.pdt_int_quantidade)::numeric) AS valor_total
   FROM ((((public.pedido
     JOIN public.pedido_item ON ((pedido.ped_cd_id = pedido_item.ped_cd_id)))
     JOIN public.produto ON ((produto.prd_cd_id = pedido_item.prd_cd_id)))
     JOIN public.categoria ON ((categoria.cat_cd_id = produto.cat_cd_id)))
     JOIN public.cliente ON ((cliente.cli_cd_id = pedido.cli_cd_id)));


--
-- Name: rel_produto_categoria; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.rel_produto_categoria AS
 SELECT c.cat_tx_nome AS categoria,
    count(p.cat_cd_id) AS quantidade
   FROM (public.categoria c
     JOIN public.produto p ON ((p.cat_cd_id = c.cat_cd_id)))
  GROUP BY c.cat_tx_nome;


--
-- Name: rel_produto_categoria_funcionario; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.rel_produto_categoria_funcionario AS
 SELECT produto.prd_tx_nome AS produto,
    categoria.cat_tx_nome AS categoria,
    funcionario.fun_tx_nome AS funcionario,
    produto.prd_int_quantidade_estoque AS estoque
   FROM ((public.produto
     JOIN public.funcionario ON ((produto.fun_cd_id = funcionario.fun_cd_id)))
     JOIN public.categoria ON ((categoria.cat_cd_id = produto.cat_cd_id)));


--
-- Name: categoria cat_cd_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoria ALTER COLUMN cat_cd_id SET DEFAULT nextval('public.categoria_cat_cd_id_seq'::regclass);


--
-- Name: cliente cli_cd_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cliente ALTER COLUMN cli_cd_id SET DEFAULT nextval('public.cliente_cli_cd_id_seq'::regclass);


--
-- Name: funcionario fun_cd_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funcionario ALTER COLUMN fun_cd_id SET DEFAULT nextval('public.funcionario_fun_cd_id_seq'::regclass);


--
-- Name: nota_fiscal nfe_cd_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nota_fiscal ALTER COLUMN nfe_cd_id SET DEFAULT nextval('public.nota_fiscal_nfe_cd_id_seq'::regclass);


--
-- Name: pedido ped_cd_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pedido ALTER COLUMN ped_cd_id SET DEFAULT nextval('public.pedido_ped_cd_id_seq'::regclass);


--
-- Name: pedido_item pdt_cd_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pedido_item ALTER COLUMN pdt_cd_id SET DEFAULT nextval('public.pedido_item_pdt_cd_id_seq'::regclass);


--
-- Name: produto prd_cd_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.produto ALTER COLUMN prd_cd_id SET DEFAULT nextval('public.produto_prd_cd_id_seq'::regclass);


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3404.dat

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3398.dat

--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3396.dat

--
-- Data for Name: nota_fiscal; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3402.dat

--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3400.dat

--
-- Data for Name: pedido_item; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3408.dat

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/3406.dat

--
-- Name: categoria_cat_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categoria_cat_cd_id_seq', 3, true);


--
-- Name: cliente_cli_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cliente_cli_cd_id_seq', 11, true);


--
-- Name: funcionario_fun_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.funcionario_fun_cd_id_seq', 5, true);


--
-- Name: nota_fiscal_nfe_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nota_fiscal_nfe_cd_id_seq', 1, false);


--
-- Name: pedido_item_pdt_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pedido_item_pdt_cd_id_seq', 11, true);


--
-- Name: pedido_ped_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pedido_ped_cd_id_seq', 5, true);


--
-- Name: produto_prd_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.produto_prd_cd_id_seq', 20, true);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (cat_cd_id);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (cli_cd_id);


--
-- Name: funcionario funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (fun_cd_id);


--
-- Name: nota_fiscal nota_fiscal_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nota_fiscal
    ADD CONSTRAINT nota_fiscal_pkey PRIMARY KEY (nfe_cd_id);


--
-- Name: pedido_item pedido_item_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pedido_item
    ADD CONSTRAINT pedido_item_pkey PRIMARY KEY (pdt_cd_id);


--
-- Name: pedido pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (ped_cd_id);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (prd_cd_id);


--
-- Name: nota_fiscal FK_nota_fiscal.ped_cd_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nota_fiscal
    ADD CONSTRAINT "FK_nota_fiscal.ped_cd_id" FOREIGN KEY (ped_cd_id) REFERENCES public.pedido(ped_cd_id);


--
-- Name: pedido FK_pedido.cli_cd_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT "FK_pedido.cli_cd_id" FOREIGN KEY (cli_cd_id) REFERENCES public.cliente(cli_cd_id);


--
-- Name: pedido_item FK_pedido_item.ped_cd_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pedido_item
    ADD CONSTRAINT "FK_pedido_item.ped_cd_id" FOREIGN KEY (ped_cd_id) REFERENCES public.pedido(ped_cd_id);


--
-- Name: pedido_item FK_pedido_item.prd_cd_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pedido_item
    ADD CONSTRAINT "FK_pedido_item.prd_cd_id" FOREIGN KEY (prd_cd_id) REFERENCES public.produto(prd_cd_id);


--
-- Name: produto FK_produto.cat_cd_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT "FK_produto.cat_cd_id" FOREIGN KEY (cat_cd_id) REFERENCES public.categoria(cat_cd_id);


--
-- Name: produto FK_produto.fun_cd_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT "FK_produto.fun_cd_id" FOREIGN KEY (fun_cd_id) REFERENCES public.funcionario(fun_cd_id);


--
-- PostgreSQL database dump complete
--

